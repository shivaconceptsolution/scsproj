from django.apps import AppConfig


class PrimeappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'primeapp'
