from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    return HttpResponse("Welcome in Django Applcation")
def si(request):
    p=45000
    r=2
    t=3
    si=(p*r*t)/100
    return HttpResponse("result is "+str(si))
def swap(request):
    a=45000
    b=2
    a,b = b,a
    return HttpResponse("result is "+str(a) + "" + str(b))    