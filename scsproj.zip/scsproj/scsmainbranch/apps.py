from django.apps import AppConfig


class ScsmainbranchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scsmainbranch'
